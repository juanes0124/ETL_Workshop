TRUNCATE fact_applications CASCADE;
TRUNCATE dim_candidate CASCADE;
TRUNCATE dim_country CASCADE;
TRUNCATE dim_technology CASCADE;
TRUNCATE dim_seniority CASCADE;
TRUNCATE dim_date CASCADE;


