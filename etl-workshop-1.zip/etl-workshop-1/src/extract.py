import pandas as pd

df = pd.read_csv("candidates.csv")

print(df.shape)
df.head()